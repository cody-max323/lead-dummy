# Lead Desk

A dependency-free dummy lead management project built with HTML, CSS and JavaScript.

## Run

Open `dist/index.html` in your browser. No installation, API keys or build step required.

## Features

- Six fictional sample leads
- Add a lead using the form
- Search contacts by name, company or email
- Change lead status and view live totals
- Responsive layout and labeled controls

This is a frontend demo. Changes are in memory and reset on refresh. There is no backend, authentication, database or email sending.

## Upload to GitHub manually

1. Extract the ZIP on your computer.
2. Create an empty repository on GitHub.
3. Choose **uploading an existing file** (or **Add file > Upload files**).
4. Drag the extracted project's contents into the upload area, including the `dist` folder and this README.
5. Commit the files. Upload the extracted files, not the ZIP itself, if you want GitHub to display the source.

## Files

- `dist/index.html`: page and add-lead dialog
- `dist/styles.css`: responsive styling
- `dist/app.js`: fictional data and interactions

## Optional Git command line

Run these inside the extracted project folder after creating an empty repository. Replace YOUR_USERNAME and YOUR_REPOSITORY first.

```sh
git init
git add .
git commit -m "Add dummy lead management demo"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```
